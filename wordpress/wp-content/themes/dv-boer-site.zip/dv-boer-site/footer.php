		<?php include('contact.php')?>
		</section><!-- main wrapper -->
	</section><!-- !main section -->
	<footer class="bp-center">
		<p>Copyright &copy; 2017 DV Boer Farms</p>
		<p>All rights reserved</p>
	</footer>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	<script>window.jQuery || document.write('<script src="<?php echo bloginfo('stylesheet_directory').'/dist/js/lib/jquery.min.js'; ?>"><\/script>')</script>
	<script>window.jQuery || document.write('<script src="<?php echo bloginfo('stylesheet_directory').'/dist/js/lib/jquery-ui.min.js'; ?>"><\/script>')</script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js" integrity="sha384-DztdAPBWPRXSA/3eYEEUWrWCy7G5KFbe8fFjk5JAIxUYHKkDx6Qin1DkWx51bBrb" crossorigin="anonymous"></script>

	<!-- Bootstrap js -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js" integrity="sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn" crossorigin="anonymous"></script>

	<!-- <script src="dist/js/owl.carousel.min.js"></script> -->
	<script src="<?php echo bloginfo('stylesheet_directory').'/dist/js/plugins.js'; ?>"></script>
	<script src="<?php echo bloginfo('stylesheet_directory').'/dist/js/all.min.js'; ?>"></script>
</body>
</html>